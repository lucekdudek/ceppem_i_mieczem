#include "location.h"
#include <string>


Location::Location()
{
}


Location::~Location()
{
}