#include "l_small_farm.h"
#include <iostream>



L_Small_Farm::L_Small_Farm()
{
}


L_Small_Farm::~L_Small_Farm()
{
}

void L_Small_Farm::runActionA() {
	std::cout << "Interakcja z Farmer" << std::endl;
}

void L_Small_Farm::runActionB() {
	std::cout << "Interakcja ze Skrzynia" << std::endl;
}

void L_Small_Farm::runActionC() {
	std::cout << "Brak" << std::endl;
}

void L_Small_Farm::runActionD() {
	std::cout << "Brak" << std::endl;
}